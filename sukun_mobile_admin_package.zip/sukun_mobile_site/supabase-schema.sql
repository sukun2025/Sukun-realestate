-- شغّل هذا الملف مرة واحدة في Supabase > SQL Editor > New query
create extension if not exists pgcrypto;
create table if not exists public.properties (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 deal_type text not null check (deal_type in ('بيع','إيجار')),
 project text not null default 'أخرى',
 area numeric,
 price numeric,
 bedrooms integer,
 bathrooms integer,
 image_url text,
 description text,
 is_published boolean not null default false,
 created_at timestamptz not null default now()
);
alter table public.properties enable row level security;
drop policy if exists "Anyone can view published properties" on public.properties;
create policy "Anyone can view published properties" on public.properties for select using (is_published = true or auth.uid() is not null);
drop policy if exists "Signed in admins manage properties" on public.properties;
create policy "Signed in admins manage properties" on public.properties for all to authenticated using (true) with check (true);
-- Bucket عام للصور فقط، لا ترفع أي مستندات خاصة أو حساسة.
insert into storage.buckets (id,name,public,file_size_limit,allowed_mime_types)
values ('property-images','property-images',true,5242880,array['image/jpeg','image/png','image/webp'])
on conflict (id) do nothing;
drop policy if exists "Public can view property images" on storage.objects;
create policy "Public can view property images" on storage.objects for select using (bucket_id = 'property-images');
drop policy if exists "Signed in users upload property images" on storage.objects;
create policy "Signed in users upload property images" on storage.objects for insert to authenticated with check (bucket_id = 'property-images');
drop policy if exists "Signed in users update property images" on storage.objects;
create policy "Signed in users update property images" on storage.objects for update to authenticated using (bucket_id = 'property-images') with check (bucket_id = 'property-images');
drop policy if exists "Signed in users delete property images" on storage.objects;
create policy "Signed in users delete property images" on storage.objects for delete to authenticated using (bucket_id = 'property-images');
