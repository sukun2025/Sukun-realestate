// ضع بيانات مشروع Supabase هنا بعد إنشائه. مفتاح anon/publishable فقط مسموح في واجهة الموقع؛ لا تضع service_role key هنا.
window.SUKUN_CONFIG = {
  url: 'YOUR_SUPABASE_PROJECT_URL',
  anonKey: 'YOUR_SUPABASE_PUBLISHABLE_OR_ANON_KEY'
};
